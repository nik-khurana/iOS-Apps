//
//  ImageDetailViewViewController.swift
//  game
//
//  Created by Amity Ny on 5/9/18.
//  Copyright © 2018 Amity. All rights reserved.
//

import UIKit

class ImageDetailViewViewController: UIViewController {
    var images = ["car1","car2","a3","car4"]
    var rowrecievd=0
    @IBOutlet weak var imgview: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        imgview.image=UIImage(named: images[rowrecievd])
        label.text = "section 1 row \(rowrecievd)"
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
