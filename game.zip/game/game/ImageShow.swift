                  //
//  ImageShow.swift
//  game
//
//  Created by Amity Ny on 5/9/18.
//  Copyright © 2018 Amity. All rights reserved.
//

import UIKit

class ImageShow: UIViewController {

    @IBOutlet weak var imgview: UIImageView!
    @IBOutlet weak var imgview1: UIImageView!
    @IBOutlet weak var imgview2: UIImageView!
    @IBOutlet weak var imgview3: UIImageView!
    @IBOutlet weak var imgview4: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let gs1 = UITapGestureRecognizer(target: self, action: #selector(imageTapped(gs:)))
        let gs2 = UITapGestureRecognizer(target: self, action: #selector(imageTapped(gs:)))
        let gs3 = UITapGestureRecognizer(target: self, action: #selector(imageTapped(gs:)))
        let gs4 = UITapGestureRecognizer(target: self, action: #selector(imageTapped(gs:)))
        imgview1.isUserInteractionEnabled = true
        imgview1.addGestureRecognizer(gs1)
        imgview2.isUserInteractionEnabled = true
        imgview2.addGestureRecognizer(gs2)
        imgview3.isUserInteractionEnabled = true
        imgview3.addGestureRecognizer(gs3)
        imgview4.isUserInteractionEnabled = true
        imgview4.addGestureRecognizer(gs4)
    }
    @objc func imageTapped(gs:UITapGestureRecognizer){
        let tapimg = gs.view as! UIImageView
        imgview.image = tapimg.image
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
