//
//  NextViewAfterCollectionViewController.swift
//  game
//
//  Created by Amity Ny on 5/19/18.
//  Copyright © 2018 Amity. All rights reserved.
//

import UIKit

class NextViewAfterCollectionViewController: UIViewController {
    @IBOutlet weak var imageview: UIImageView!
    var url : URL!
    override func viewDidLoad() {
        super.viewDidLoad()
        let data = try? Data(contentsOf: url)
        
        if let imageData = data {
            let image = UIImage(data: imageData)
            imageview.image = image
        }
        
        // Do any additional setup after loading the view.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
