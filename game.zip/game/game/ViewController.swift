//
//  ViewController.swift
//  game
//
//  Created by Amity Ny on 4/30/18.
//  Copyright © 2018 Amity. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b4: UIButton!
    @IBOutlet weak var b5: UIButton!
    @IBOutlet weak var b6: UIButton!
    @IBOutlet weak var b7: UIButton!
    @IBOutlet weak var b8: UIButton!
    @IBOutlet weak var b9: UIButton!
    @IBOutlet weak var score: UILabel!
    var timer=Timer()
    var tempscore=0
    var current=UIButton()
    @IBOutlet weak var gameover: UILabel!
    @IBAction func gamestart(_ sender: Any) {
        if gameover.text == "GAME OVER"{
            tempscore=0
            gameover.text=String("GOOD LUCK")
            score.text="Score : 0"
            timer=Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.addImage), userInfo: nil, repeats: true)
        }
    }
    @objc func addImage(){
        current.setBackgroundImage(nil, for: UIControlState.normal)
        let random = arc4random_uniform(9)+1
        switch(random){
        case 1:
            current=b1
            break
        case 2:
            current=b2
            break
        case 3:
            current=b3
            break
        case 4:
            current=b3
            break
        case 5:
            current=b5
            break
        case 6:
            current=b6
            break
        case 7:
            current=b7
            break
        case 8:
            current=b8
            break
        case 9:
            current=b9
            break
        default:
            break
        }
        current.setBackgroundImage(UIImage(named:"abc"), for: UIControlState.normal)
    }
    @IBAction func b1tap(_ sender: Any) {
        if current.isEqual(b1){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b2tap(_ sender: Any) {
        if current.isEqual(b2){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b3tap(_ sender: Any) {
        if current.isEqual(b3){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b4tap(_ sender: Any) {
        if current.isEqual(b4){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b5tap(_ sender: Any) {
        if current.isEqual(b5){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b6tap(_ sender: Any) {
        if current.isEqual(b6){
            tempscore=tempscore+1
            score.text="Score : "+String(tempscore)
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b7tap(_ sender: Any) {
   
        if current.isEqual(b7){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b8tap(_ sender: Any) {
        if current.isEqual(b8){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    @IBAction func b9tap(_ sender: Any) {
        if current.isEqual(b9){
            if gameover.text != "GAME OVER"{
                tempscore=tempscore+1
                score.text="Score : "+String(tempscore)
            }
            
        }
        else{
            gameover.text=String("GAME OVER")
            timer.invalidate()
            current.setBackgroundImage(nil, for: UIControlState.normal)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

