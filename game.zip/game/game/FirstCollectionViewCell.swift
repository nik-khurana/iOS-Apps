//
//  FirstCollectionViewCell.swift
//  game
//
//  Created by Amity Ny on 5/19/18.
//  Copyright © 2018 Amity. All rights reserved.
//

import UIKit

class FirstCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imagetodisplay: UIImageView!
}
